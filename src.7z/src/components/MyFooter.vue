<template>
  <footer class="footer">
    <div class="container">
      <div class="content has-text-centered">
        <p>
          Page is rendered by Kontent
        </p>
        <p>
          <strong>Kontent</strong> by
          Cubelrti. The source code is licensed
          <a href="http://opensource.org/licenses/mit-license.php">MIT</a>.
        </p>
      </div>
    </div>
  </footer>
</template>

<script>
export default {
  
}
</script>

<style scoped>
  footer{
    background-color: whitesmoke;
  }

</style>
